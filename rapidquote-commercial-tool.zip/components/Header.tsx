import React from 'react';
import type { View } from '../types';

interface HeaderProps {
  activeView: View;
  setActiveView: (view: 'lead') => void;
  onNavigateToQuote: () => void;
}

const NavButton: React.FC<{
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, isActive, onClick }) => {
  const baseClasses = "px-4 py-2 rounded-md text-sm sm:text-base font-semibold transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500";
  const activeClasses = "bg-indigo-600 text-white shadow-md";
  const inactiveClasses = "bg-white text-indigo-600 hover:bg-indigo-50";

  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
    >
      {label}
    </button>
  );
};

const Header: React.FC<HeaderProps> = ({ activeView, setActiveView, onNavigateToQuote }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <svg className="h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3a1 1 0 00-1-1H9a1 1 0 00-1 1v3m10-3l-3-3m0 0l-3 3m3-3v12" />
          </svg>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-800">RapidQuote</h1>
        </div>
        <nav className="flex items-center space-x-2 sm:space-x-4 bg-slate-100 p-1 rounded-lg">
          <NavButton 
            label="New Lead" 
            isActive={activeView === 'lead'}
            onClick={() => setActiveView('lead')} 
          />
          <NavButton 
            label="Create Quote" 
            isActive={activeView === 'quote'}
            onClick={onNavigateToQuote} 
          />
        </nav>
      </div>
    </header>
  );
};

export default Header;