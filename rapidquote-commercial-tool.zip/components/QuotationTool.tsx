
import React, { useState, useMemo } from 'react';
import { useProducts } from '../context/ProductContext';
import type { QuoteItem, Product, ProductCategory } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import { MinusIcon } from './icons/MinusIcon';
import { TrashIcon } from './icons/TrashIcon';

const QuotationTool: React.FC = () => {
  const [quoteItems, setQuoteItems] = useState<QuoteItem[]>([]);
  const [showFinalQuote, setShowFinalQuote] = useState(false);
  const [quoteNumber] = useState(`QT-${Math.floor(100000 + Math.random() * 900000)}`);
  const [path, setPath] = useState<string[]>([]);
  const { productCategories } = useProducts();

  const addItemToQuote = (product: Product) => {
    setQuoteItems(prevItems => {
      const existingItem = prevItems.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevItems, { product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItemFromQuote(productId);
    } else {
      setQuoteItems(prevItems =>
        prevItems.map(item =>
          item.product.id === productId ? { ...item, quantity: newQuantity } : item
        )
      );
    }
  };

  const removeItemFromQuote = (productId: number) => {
    setQuoteItems(prevItems => prevItems.filter(item => item.product.id !== productId));
  };
  
  const totalCost = useMemo(() => {
    return quoteItems.reduce((total, item) => total + item.product.price * item.quantity, 0);
  }, [quoteItems]);
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  const navigateTo = (categoryName: string) => {
    setPath(prev => [...prev, categoryName]);
  };

  const navigateBack = () => {
    setPath(prev => prev.slice(0, -1));
  };

  const currentContent = useMemo(() => {
    if (path.length === 0) {
      return { name: 'Categories', subcategories: productCategories, products: [] };
    }
    
    let level: ProductCategory | undefined;
    let categoriesToSearch: ProductCategory[] | undefined = productCategories;

    for (const segment of path) {
      if (!categoriesToSearch) {
        level = undefined;
        break;
      }
      level = categoriesToSearch.find(c => c.name === segment);
      categoriesToSearch = level?.subcategories;
    }
    return level;
  }, [path, productCategories]);

  const breadcrumbs = ['Categories', ...path].join(' / ');

  const CategoryButton: React.FC<{ category: ProductCategory }> = ({ category }) => (
    <button
      onClick={() => navigateTo(category.name)}
      className="bg-white p-6 rounded-lg shadow-md flex items-center justify-between transition-all duration-200 hover:shadow-lg hover:bg-indigo-50 hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
    >
      <span className="font-semibold text-lg text-slate-800">{category.name}</span>
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
      </svg>
    </button>
  );

  const ProductItem: React.FC<{ product: Product }> = ({ product }) => (
    <div className="bg-white p-4 rounded-lg shadow-md flex items-center justify-between transition-shadow hover:shadow-lg">
      <div>
        <h3 className="font-semibold text-slate-800">{product.name}</h3>
        <p className="text-sm text-slate-500">{product.description}</p>
        <p className="text-sm font-bold text-indigo-600 mt-1">{formatCurrency(product.price)}</p>
      </div>
      <button
        onClick={() => addItemToQuote(product)}
        className="bg-indigo-100 text-indigo-700 hover:bg-indigo-200 font-semibold py-2 px-4 rounded-lg transition-colors duration-200 flex items-center space-x-2"
      >
        <PlusIcon className="h-5 w-5"/>
        <span>Add</span>
      </button>
    </div>
  );

  return (
    <>
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
      {/* Product & Category Browser */}
      <div className="lg:col-span-3">
        <div className="flex items-center mb-4 text-sm font-medium">
          {path.length > 0 && (
            <button onClick={navigateBack} className="flex items-center text-slate-500 hover:text-indigo-600 mr-2 p-1 rounded-md hover:bg-slate-100 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span className="ml-1">Back</span>
            </button>
          )}
          <p className="text-slate-400 truncate">{breadcrumbs}</p>
        </div>
        
        <h2 className="text-2xl font-bold text-slate-800 mb-6">
          {currentContent?.name || 'Select an Option'}
        </h2>
        
        <div className="space-y-4">
          {currentContent?.subcategories && currentContent.subcategories.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentContent.subcategories.map(category => <CategoryButton key={category.name} category={category} />)}
            </div>
          )}
          
          {currentContent?.products && currentContent.products.length > 0 && (
              currentContent.products.map(product => <ProductItem key={product.id} product={product} />)
          )}

          {(currentContent?.subcategories?.length === 0 || !currentContent?.subcategories) && 
           (currentContent?.products?.length === 0 || !currentContent?.products) && (
            <div className="text-center py-10 px-4 bg-white rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-slate-700">No more options</h3>
              <p className="text-slate-500 mt-1">There are no further selections in this category.</p>
            </div>
          )}
        </div>
      </div>

      {/* Quotation Summary */}
      <div className="lg:col-span-2">
        <div className="sticky top-24">
            <div className="bg-white p-6 rounded-xl shadow-lg">
                <div className="flex justify-between items-baseline border-b pb-4 mb-4">
                    <h2 className="text-2xl font-bold text-slate-800">Current Quotation</h2>
                    <span className="font-mono text-sm text-slate-500">#{quoteNumber}</span>
                </div>
                {quoteItems.length === 0 ? (
                    <p className="text-slate-500 text-center py-10">Select products to build your quote.</p>
                ) : (
                    <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-2">
                        {quoteItems.map(item => (
                            <div key={item.product.id} className="flex justify-between items-start">
                                <div>
                                    <p className="font-semibold text-slate-700">{item.product.name}</p>
                                    <p className="text-sm text-slate-500">{formatCurrency(item.product.price)}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className="p-1 rounded-full bg-slate-200 hover:bg-slate-300"><MinusIcon className="h-4 w-4"/></button>
                                    <span className="w-8 text-center font-medium">{item.quantity}</span>
                                    <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className="p-1 rounded-full bg-slate-200 hover:bg-slate-300"><PlusIcon className="h-4 w-4"/></button>
                                    <button onClick={() => removeItemFromQuote(item.product.id)} className="p-1 rounded-full text-red-500 hover:bg-red-100"><TrashIcon className="h-4 w-4"/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
                <div className="mt-6 pt-6 border-t">
                    <div className="flex justify-between items-center text-xl font-bold">
                        <span>Total</span>
                        <span>{formatCurrency(totalCost)}</span>
                    </div>
                    <button 
                        onClick={() => setShowFinalQuote(true)}
                        disabled={quoteItems.length === 0}
                        className="w-full mt-6 bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition duration-300 ease-in-out disabled:bg-slate-400 disabled:cursor-not-allowed">
                        Generate Final Quote
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>
    
    {/* Final Quote Modal */}
    {showFinalQuote && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full p-8 relative animate-slide-up">
                <button onClick={() => setShowFinalQuote(false)} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800">
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
                <div className="text-center mb-6">
                    <h2 className="text-3xl font-bold text-slate-800">Final Quotation</h2>
                    <p className="text-lg text-slate-500 font-mono mt-1">#{quoteNumber}</p>
                </div>
                <div className="border-t border-b divide-y">
                    <div className="flex justify-between font-semibold py-2 bg-slate-50 px-4">
                        <span className="w-3/5">Item Description</span>
                        <span className="w-1/5 text-center">Quantity</span>
                        <span className="w-1/5 text-right">Subtotal</span>
                    </div>
                     {quoteItems.map(item => (
                        <div key={item.product.id} className="flex justify-between items-center py-3 px-4">
                            <span className="w-3/5 font-medium">{item.product.name}</span>
                            <span className="w-1/5 text-center">{item.quantity}</span>
                            <span className="w-1/5 text-right">{formatCurrency(item.product.price * item.quantity)}</span>
                        </div>
                    ))}
                </div>
                <div className="flex justify-end items-center mt-6 pt-6 border-t">
                    <span className="text-lg font-bold mr-4">Grand Total:</span>
                    <span className="text-2xl font-extrabold text-indigo-600">{formatCurrency(totalCost)}</span>
                </div>
                 <div className="mt-8 text-center">
                    <button onClick={() => window.print()} className="bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 transition">Print or Save as PDF</button>
                </div>
            </div>
        </div>
    )}
    </>
  );
};

export default QuotationTool;