import React, { useState, useMemo } from 'react';
import { useProducts } from '../context/ProductContext';
import { useClients } from '../context/ClientContext';
import type { FlatProduct, ProductCategory, SpecialClient } from '../types';

const PriceList: React.FC = () => {
  const { productCategories, updatePrices } = useProducts();
  const { specialClients, updateClients } = useClients();

  // State for product price updates
  const [isPriceProcessing, setIsPriceProcessing] = useState(false);
  const [priceError, setPriceError] = useState<string | null>(null);
  const [priceSuccess, setPriceSuccess] = useState<string | null>(null);
  const priceFileInputRef = React.useRef<HTMLInputElement>(null);

  // State for special client updates
  const [isClientProcessing, setIsClientProcessing] = useState(false);
  const [clientError, setClientError] = useState<string | null>(null);
  const [clientSuccess, setClientSuccess] = useState<string | null>(null);
  const clientFileInputRef = React.useRef<HTMLInputElement>(null);


  const allProductsFlat = useMemo((): FlatProduct[] => {
    const flatten = (categories: ProductCategory[], parentPath: string = ''): FlatProduct[] => {
      let flatList: FlatProduct[] = [];
      categories.forEach(category => {
        const currentPath = parentPath ? `${parentPath} / ${category.name}` : category.name;
        if (category.products) {
          category.products.forEach(product => {
            flatList.push({ product, path: currentPath });
          });
        }
        if (category.subcategories && category.subcategories.length > 0) {
          flatList = flatList.concat(flatten(category.subcategories, currentPath));
        }
      });
      return flatList;
    };
    return flatten(productCategories);
  }, [productCategories]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };
  
  const handlePriceFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsPriceProcessing(true);
    setPriceError(null);
    setPriceSuccess(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        const parsedData = parsePriceUpdateCsv(text);
        const updatedCount = updatePrices(parsedData);
        
        if (updatedCount > 0) {
            setPriceSuccess(`Successfully updated prices for ${updatedCount} product(s).`);
        } else {
            setPriceError("No matching product names found in the catalog. Please ensure names in the CSV exactly match the catalog names.");
        }

      } catch (err: any) {
        setPriceError(err.message || 'An unknown error occurred during processing.');
      } finally {
        setIsPriceProcessing(false);
        if(priceFileInputRef.current) {
            priceFileInputRef.current.value = "";
        }
      }
    };
    reader.onerror = () => {
        setPriceError("Failed to read the file.");
        setIsPriceProcessing(false);
    };
    reader.readAsText(file);
  };
  
  const parsePriceUpdateCsv = (csvText: string): { name: string; price: number }[] => {
    const lines = csvText.trim().split(/\r?\n/);
    if (lines.length < 2) throw new Error("CSV file is empty or has no data rows.");

    const header = lines[0].split(',').map(h => h.trim().toLowerCase());
    const requiredHeaders = ['name', 'price'];
    
    for(const reqHeader of requiredHeaders){
        if(!header.includes(reqHeader)){
            throw new Error(`CSV is missing required header: "${reqHeader}". Headers must be: ${requiredHeaders.join(', ')}.`);
        }
    }
    
    const nameIndex = header.indexOf('name');
    const priceIndex = header.indexOf('price');

    const dataRows = lines.slice(1);
    return dataRows.map((line, index) => {
        const values = line.split(',');
        const name = values[nameIndex]?.trim();
        const priceStr = values[priceIndex]?.trim();
        
        if (!name || !priceStr) {
           throw new Error(`Row ${index + 2}: Missing required data. Each row needs both a name and a price.`);
        }

        const price = parseFloat(priceStr);
        if(isNaN(price)){
            throw new Error(`Row ${index + 2}: Invalid price format for product "${name}". Price must be a number.`);
        }

        return { name, price };
    });
  };

  const handleClientFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsClientProcessing(true);
    setClientError(null);
    setClientSuccess(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const text = e.target?.result as string;
            const newClients = parseClientCsv(text);
            updateClients(newClients);
            setClientSuccess(`Successfully updated the special client list with ${newClients.length} record(s).`);
        } catch (err: any) {
            setClientError(err.message || 'An unknown error occurred during processing.');
        } finally {
            setIsClientProcessing(false);
            if(clientFileInputRef.current) {
                clientFileInputRef.current.value = "";
            }
        }
    };
    reader.onerror = () => {
        setClientError("Failed to read the file.");
        setIsClientProcessing(false);
    };
    reader.readAsText(file);
  };
  
  const parseClientCsv = (csvText: string): SpecialClient[] => {
      const lines = csvText.trim().split(/\r?\n/);
      if (lines.length < 2) throw new Error("Client CSV file is empty or has no data rows.");

      const header = lines[0].split(',').map(h => h.trim().toLowerCase());
      const requiredHeaders = ['name', 'discount'];

      for(const reqHeader of requiredHeaders){
          if(!header.includes(reqHeader)){
              throw new Error(`Client CSV is missing required header: "${reqHeader}". Headers must be: ${requiredHeaders.join(', ')}.`);
          }
      }

      const nameIndex = header.indexOf('name');
      const discountIndex = header.indexOf('discount');
      
      const dataRows = lines.slice(1);
      return dataRows.map((line, index) => {
          const values = line.split(',');
          const name = values[nameIndex]?.trim();
          const discount = values[discountIndex]?.trim();
          
          if (!name || !discount) {
             throw new Error(`Row ${index + 2}: Missing required data. Each row needs both a name and a discount.`);
          }
          return { name, discount };
      });
  };

  return (
    <div className="space-y-12 animate-fade-in">
      {/* Product Price List Section */}
      <div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Complete Product Price List</h2>
        <p className="text-slate-500 mb-6">A comprehensive list of all available products and their standard pricing. This list is for internal use only.</p>
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-slate-500">
              <thead className="text-xs text-slate-700 uppercase bg-slate-50 border-b border-slate-200">
                <tr>
                  <th scope="col" className="px-6 py-3 font-semibold w-2/5">Product Name</th>
                  <th scope="col" className="px-6 py-3 font-semibold w-2/5">Category Path</th>
                  <th scope="col" className="px-6 py-3 font-semibold w-1/5 text-right">Price</th>
                </tr>
              </thead>
              <tbody>
                {allProductsFlat.length > 0 ? (
                  allProductsFlat.map(({ product, path }) => (
                  <tr key={product.id} className="bg-white border-b border-slate-200 last:border-b-0 hover:bg-slate-50">
                    <th scope="row" className="px-6 py-4 font-medium text-slate-900 whitespace-nowrap">
                      {product.name}
                    </th>
                    <td className="px-6 py-4 text-slate-600">{path}</td>
                    <td className="px-6 py-4 text-right font-semibold text-indigo-600">{formatCurrency(product.price)}</td>
                  </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="text-center py-10 px-6 text-slate-500">
                        No products found. The catalog might be empty.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Catalog Management Section */}
      <div className="border-t pt-10">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Update Product Prices via CSV</h2>
        <p className="text-slate-500 mb-4">Upload a CSV file to update product prices in bulk. The system will match products by name.</p>
        <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="prose prose-sm prose-slate max-w-none mb-4 bg-slate-50 p-4 rounded-lg">
                <h4>CSV File Instructions:</h4>
                <ul>
                    <li>The file must be a standard CSV.</li>
                    <li>The header row is required and must contain these exact column names (case-insensitive): <code>name,price</code></li>
                    <li>The <code>name</code> must exactly match the product name in the catalog to be updated.</li>
                    <li>The <code>price</code> column must contain only numbers.</li>
                    <li>Products in the CSV that are not found in the catalog will be ignored.</li>
                </ul>
            </div>
            
            <input
                type="file"
                accept=".csv"
                onChange={handlePriceFileChange}
                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                disabled={isPriceProcessing}
                ref={priceFileInputRef}
            />
            {isPriceProcessing && <p className="text-sm text-indigo-600 mt-4 animate-pulse">Processing, please wait...</p>}
            {priceError && <p className="text-sm text-red-600 mt-4"><b>Error:</b> {priceError}</p>}
            {priceSuccess && <p className="text-sm text-green-600 mt-4"><b>Success:</b> {priceSuccess}</p>}
        </div>
      </div>

      {/* Special Clients Section */}
      <div className="border-t pt-10">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Special Client Discounts</h2>
        <p className="text-slate-500 mb-6">List of clients with special discount agreements. Use the uploader below to update this entire list.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {specialClients.map(client => (
            <div key={client.name} className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex justify-between items-start">
                  <h3 className="text-xl font-bold text-slate-800">{client.name}</h3>
                  <span className="bg-emerald-100 text-emerald-800 text-sm font-bold px-3 py-1 rounded-full">{client.discount}</span>
              </div>
              {client.notes && <p className="text-slate-600 mt-2">{client.notes}</p>}
            </div>
          ))}
        </div>
      </div>
      
      {/* Client List Management Section */}
      <div className="border-t pt-10">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Update Client List via CSV</h2>
        <p className="text-slate-500 mb-4">Upload a CSV file to replace the entire special clients list.</p>
        <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="prose prose-sm prose-slate max-w-none mb-4 bg-slate-50 p-4 rounded-lg">
                <h4>CSV File Instructions:</h4>
                <ul>
                    <li>The file must be a standard CSV.</li>
                    <li>The header row is required and must contain these exact column names (case-insensitive): <code>name,discount</code></li>
                    <li>Uploading a new file will <strong>replace all</strong> existing client data.</li>
                </ul>
            </div>
            
            <input
                type="file"
                accept=".csv"
                onChange={handleClientFileChange}
                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                disabled={isClientProcessing}
                ref={clientFileInputRef}
            />
            {isClientProcessing && <p className="text-sm text-indigo-600 mt-4 animate-pulse">Processing, please wait...</p>}
            {clientError && <p className="text-sm text-red-600 mt-4"><b>Error:</b> {clientError}</p>}
            {clientSuccess && <p className="text-sm text-green-600 mt-4"><b>Success:</b> {clientSuccess}</p>}
        </div>
      </div>
    </div>
  );
};

export default PriceList;