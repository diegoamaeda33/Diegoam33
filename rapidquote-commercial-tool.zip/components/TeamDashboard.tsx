
import React, { useState } from 'react';
import type { TeamView } from '../types';
import QuotationTool from './QuotationTool';
import PriceList from './PriceList';

const TeamDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TeamView>('quotationTool');

  const NavTab: React.FC<{ label: string; view: TeamView; }> = ({ label, view }) => {
    const isActive = activeTab === view;
    return (
      <button
        onClick={() => setActiveTab(view)}
        className={`px-4 sm:px-6 py-3 font-semibold text-sm rounded-t-lg transition-colors focus:outline-none -mb-px border-b-2 ${
          isActive
            ? 'border-indigo-600 text-indigo-600'
            : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
        }`}
        role="tab"
        aria-selected={isActive}
      >
        {label}
      </button>
    );
  };

  return (
    <div className="w-full">
      <div className="border-b border-slate-200">
        <nav className="flex space-x-2 sm:space-x-4" aria-label="Tabs" role="tablist">
          <NavTab label="Create Quote" view="quotationTool" />
          <NavTab label="Price & Client List" view="priceList" />
        </nav>
      </div>

      <div className="mt-8">
        {activeTab === 'quotationTool' && <QuotationTool />}
        {activeTab === 'priceList' && <PriceList />}
      </div>
    </div>
  );
};

export default TeamDashboard;
