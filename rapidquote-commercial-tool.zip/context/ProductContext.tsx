import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import type { ProductCategory } from '../types';
import { INITIAL_PRODUCT_CATEGORIES } from '../constants';

interface ProductContextType {
  productCategories: ProductCategory[];
  updatePrices: (priceUpdates: { name: string; price: number }[]) => number;
  isLoading: boolean;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [productCategories, setProductCategories] = useState<ProductCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const storedCategories = localStorage.getItem('productCatalog');
      if (storedCategories) {
        setProductCategories(JSON.parse(storedCategories));
      } else {
        setProductCategories(INITIAL_PRODUCT_CATEGORIES);
      }
    } catch (error) {
      console.error("Failed to load or parse product catalog from localStorage:", error);
      setProductCategories(INITIAL_PRODUCT_CATEGORIES);
    } finally {
        setIsLoading(false);
    }
  }, []);

  const updatePrices = useCallback((priceUpdates: { name: string; price: number }[]): number => {
    const priceMap = new Map(priceUpdates.map(p => [p.name, p.price]));
    let updatedCount = 0;

    const recursivelyUpdate = (categories: ProductCategory[]): ProductCategory[] => {
        if (!categories || categories.length === 0) return [];
        
        return categories.map(category => {
            const updatedProducts = category.products.map(product => {
                if (priceMap.has(product.name)) {
                    updatedCount++;
                    return { ...product, price: priceMap.get(product.name)! };
                }
                return product;
            });

            return {
                ...category,
                products: updatedProducts,
                subcategories: recursivelyUpdate(category.subcategories),
            };
        });
    };
    
    // Using functional update to ensure we have the latest state
    let finalUpdatedCount = 0;
    setProductCategories(prevCategories => {
        updatedCount = 0; // Reset counter for this specific update operation
        const newCategories = recursivelyUpdate(prevCategories);
        finalUpdatedCount = updatedCount;

        if (finalUpdatedCount > 0) {
            try {
                localStorage.setItem('productCatalog', JSON.stringify(newCategories));
            } catch (error) {
                console.error("Failed to save product catalog to localStorage:", error);
            }
            return newCategories;
        }
        return prevCategories; // Return old state if no changes
    });

    return finalUpdatedCount;

  }, []);


  const value = { productCategories, updatePrices, isLoading };

  return (
    <ProductContext.Provider value={value}>
      {!isLoading && children}
    </ProductContext.Provider>
  );
};

export const useProducts = (): ProductContextType => {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};
