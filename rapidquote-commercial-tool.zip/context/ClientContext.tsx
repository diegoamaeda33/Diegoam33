import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import type { SpecialClient } from '../types';
import { INITIAL_SPECIAL_CLIENTS } from '../constants';

interface ClientContextType {
  specialClients: SpecialClient[];
  updateClients: (newClients: SpecialClient[]) => void;
  isLoading: boolean;
}

const ClientContext = createContext<ClientContextType | undefined>(undefined);

export const ClientProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [specialClients, setSpecialClients] = useState<SpecialClient[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const storedClients = localStorage.getItem('specialClients');
      if (storedClients) {
        setSpecialClients(JSON.parse(storedClients));
      } else {
        setSpecialClients(INITIAL_SPECIAL_CLIENTS);
      }
    } catch (error) {
      console.error("Failed to load special clients from localStorage:", error);
      setSpecialClients(INITIAL_SPECIAL_CLIENTS);
    } finally {
        setIsLoading(false);
    }
  }, []);

  const updateClients = useCallback((newClients: SpecialClient[]) => {
    setSpecialClients(newClients);
    try {
        localStorage.setItem('specialClients', JSON.stringify(newClients));
    } catch (error) {
        console.error("Failed to save special clients to localStorage:", error);
    }
  }, []);

  const value = { specialClients, updateClients, isLoading };

  return (
    <ClientContext.Provider value={value}>
      {!isLoading && children}
    </ClientContext.Provider>
  );
};

export const useClients = (): ClientContextType => {
  const context = useContext(ClientContext);
  if (context === undefined) {
    throw new Error('useClients must be used within a ClientProvider');
  }
  return context;
};
